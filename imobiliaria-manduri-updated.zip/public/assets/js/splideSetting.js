new Splide( '#splide', {
	type   : 'loop',
	perPage: 3,
	perMove: 1,
} ).mount();